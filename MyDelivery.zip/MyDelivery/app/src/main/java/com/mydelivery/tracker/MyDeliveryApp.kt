package com.mydelivery.tracker

import android.app.Application
import com.mydelivery.tracker.data.AppDatabase
import com.mydelivery.tracker.data.SettingsRepository
import com.mydelivery.tracker.data.ShiftRepository

class MyDeliveryApp : Application() {
    lateinit var shiftRepository: ShiftRepository
        private set
    lateinit var settingsRepository: SettingsRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val db = AppDatabase.getInstance(this)
        shiftRepository = ShiftRepository(db.shiftDao())
        settingsRepository = SettingsRepository(this)
    }
}
