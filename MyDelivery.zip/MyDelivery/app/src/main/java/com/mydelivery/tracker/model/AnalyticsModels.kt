package com.mydelivery.tracker.model

import java.time.LocalDate

data class WeekdayBreakdownRow(
    val weekdayName: String,
    val date: LocalDate,
    val hours: Double,
    val income: Double,
    val incomePerHour: Double
)

data class HourWindow(
    val startHour: Int,
    val endHour: Int,
    val ratePerHour: Double
) {
    val label: String get() = "%02d:00–%02d:00".format(startHour % 24, endHour % 24)
}

data class BestHoursBlock(
    val weekdayWindows: List<HourWindow>,
    val weekendWindows: List<HourWindow>
)

data class Records(
    val bestShiftDate: LocalDate?,
    val bestShiftIncome: Double,
    val bestPerHourDate: LocalDate?,
    val bestPerHour: Double,
    val maxOrdersDate: LocalDate?,
    val maxOrders: Int
)
