package com.mydelivery.tracker.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mydelivery.tracker.data.Shift
import com.mydelivery.tracker.data.ShiftRepository
import com.mydelivery.tracker.model.DayRow
import com.mydelivery.tracker.model.Formulas
import com.mydelivery.tracker.model.MonthSummary
import com.mydelivery.tracker.model.WeekGroup
import com.mydelivery.tracker.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import java.time.LocalDate
import java.time.temporal.ChronoUnit

class HomeViewModel(private val repository: ShiftRepository) : ViewModel() {

    private val _months = MutableStateFlow<List<MonthSummary>>(emptyList())
    val months: StateFlow<List<MonthSummary>> = _months

    private val _weeks = MutableStateFlow<List<WeekGroup>>(emptyList())
    val weeks: StateFlow<List<WeekGroup>> = _weeks

    init {
        repository.observeAll().onEach { shifts -> recompute(shifts) }.launchIn(viewModelScope)
    }

    private fun recompute(shifts: List<Shift>) {
        val byDate = shifts.associateBy { LocalDate.ofEpochDay(it.dateEpochDay) }
        val today = LocalDate.now()

        // Месяцы: текущий + 5 предыдущих
        val monthList = (0..5).map { offset ->
            val monthDate = today.minusMonths(offset.toLong()).withDayOfMonth(1)
            val nextMonth = monthDate.plusMonths(1)
            val monthShifts = shifts.filter {
                val d = LocalDate.ofEpochDay(it.dateEpochDay)
                !d.isBefore(monthDate) && d.isBefore(nextMonth)
            }
            MonthSummary(
                monthDate = monthDate,
                label = DateUtils.monthLabel(monthDate),
                income = monthShifts.sumOf { Formulas.totalIncome(it) },
                workedDays = monthShifts.size,
                workedHours = monthShifts.sumOf { Formulas.totalHours(it) }
            )
        }
        _months.value = monthList

        // Недели: от текущей недели назад, показываем недели где есть хотя бы 1 смена + текущую неделю
        val currentMonday = DateUtils.mondayOf(today)
        val earliestDate = shifts.minOfOrNull { LocalDate.ofEpochDay(it.dateEpochDay) } ?: today
        val earliestMonday = DateUtils.mondayOf(earliestDate)
        val weekCount = ChronoUnit.WEEKS.between(earliestMonday, currentMonday).toInt().coerceAtLeast(0) + 1

        val weekList = (0 until weekCount).map { offset ->
            val monday = currentMonday.minusWeeks(offset.toLong())
            val days = (0..6).map { dayOffset ->
                val date = monday.plusDays(dayOffset.toLong())
                val shift = byDate[date]
                if (shift != null) {
                    DayRow(
                        date = date,
                        hasShift = true,
                        income = Formulas.totalIncome(shift),
                        samokatHours = Formulas.samokatHours(shift),
                        samokatOrders = shift.samokatOrders,
                        yandexHours = Formulas.yandexHours(shift),
                        incomePerHour = Formulas.incomePerHour(shift)
                    )
                } else {
                    DayRow(date, false, 0.0, 0.0, 0, 0.0, 0.0)
                }
            }
            WeekGroup(monday, DateUtils.weekRangeLabel(monday), days)
        }
        _weeks.value = weekList
    }
}
