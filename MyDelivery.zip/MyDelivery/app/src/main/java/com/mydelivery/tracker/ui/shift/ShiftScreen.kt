package com.mydelivery.tracker.ui.shift

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mydelivery.tracker.data.AppSettings
import com.mydelivery.tracker.data.Shift
import com.mydelivery.tracker.model.Formulas
import com.mydelivery.tracker.ui.theme.*
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShiftScreen(
    viewModel: ShiftViewModel,
    date: LocalDate,
    settings: AppSettings,
    onBack: () -> Unit
) {
    LaunchedEffect(date) { viewModel.load(date, settings) }
    val shift by viewModel.shift.collectAsState()
    val isNew by viewModel.isNew.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Смена · ${date.dayOfMonth}.${date.monthValue}.${date.year}") },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = White)
            )
        },
        containerColor = White
    ) { padding ->
        val s = shift ?: return@Scaffold
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { Spacer(Modifier.height(4.dp)) }

            item {
                AppCard(background = SamokatTint) {
                    Text("Самокат", fontWeight = FontWeight.Bold, color = SamokatAccent)
                    Spacer(Modifier.height(10.dp))
                    TimeField("Начало смены", s.samokatStart) { v -> viewModel.update { it.copy(samokatStart = v) } }
                    TimeField("Конец смены", s.samokatEnd) { v -> viewModel.update { it.copy(samokatEnd = v) } }
                    NumberField("Количество заказов", s.samokatOrders.toString()) { v ->
                        viewModel.update { it.copy(samokatOrders = v.toIntOrNull() ?: 0) }
                    }
                    NumberField("Тяжёлые заказы", s.samokatHeavyOrders.toString()) { v ->
                        viewModel.update { it.copy(samokatHeavyOrders = v.toIntOrNull() ?: 0) }
                    }
                    NumberField("Поздние выдачи", s.samokatLateOrders.toString()) { v ->
                        viewModel.update { it.copy(samokatLateOrders = v.toIntOrNull() ?: 0) }
                    }
                    DecimalField("Чаевые", s.samokatTips) { v -> viewModel.update { it.copy(samokatTips = v) } }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = s.badWeather, onCheckedChange = { v ->
                            viewModel.update { it.copy(badWeather = v) }
                        })
                        Text("Плохая погода (+10 ₽ за заказ)")
                    }
                }
            }

            item {
                AppCard(background = YandexTint) {
                    Text("Яндекс", fontWeight = FontWeight.Bold, color = YandexAccent)
                    Spacer(Modifier.height(10.dp))
                    TimeField("Начало смены", s.yandexStart) { v -> viewModel.update { it.copy(yandexStart = v) } }
                    TimeField("Конец смены", s.yandexEnd) { v -> viewModel.update { it.copy(yandexEnd = v) } }
                    DecimalField("Доход", s.yandexIncome) { v -> viewModel.update { it.copy(yandexIncome = v) } }
                    DecimalField("Чаевые", s.yandexTips) { v -> viewModel.update { it.copy(yandexTips = v) } }
                }
            }

            item {
                AppCard {
                    Text("Расходы", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    DecimalField("Сумма расходов", s.expenses) { v -> viewModel.update { it.copy(expenses = v) } }
                }
            }

            item {
                AppCard {
                    Text("Итоги смены", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    SummaryRow("Доход Самокат", formatMoney(Formulas.samokatIncome(s), s.currency))
                    SummaryRow("Доход Яндекс", formatMoney(Formulas.yandexIncome(s), s.currency))
                    SummaryRow("Общий доход", formatMoney(Formulas.totalIncome(s), s.currency))
                    SummaryRow("Чистый доход", formatMoney(Formulas.netIncome(s), s.currency), highlight = true)
                    SummaryRow("Доход в час", formatMoney(Formulas.incomePerHour(s), s.currency))
                }
            }

            item {
                Button(
                    onClick = { viewModel.save(onBack) },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green)
                ) {
                    Text("Сохранить смену", fontWeight = FontWeight.Bold)
                }
            }

            if (!isNew) {
                item {
                    OutlinedButton(
                        onClick = { viewModel.delete(onBack) },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = SamokatAccent)
                    ) {
                        Text("Удалить смену")
                    }
                }
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun TimeField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it) },
        label = { Text(label) },
        placeholder = { Text("09:00") },
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        singleLine = true
    )
}

@Composable
private fun NumberField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter { c -> c.isDigit() }) },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        singleLine = true
    )
}

@Composable
private fun DecimalField(label: String, value: Double, onChange: (Double) -> Unit) {
    var text by remember(value) { mutableStateOf(if (value == 0.0) "" else value.toString()) }
    OutlinedTextField(
        value = text,
        onValueChange = {
            text = it
            onChange(it.replace(',', '.').toDoubleOrNull() ?: 0.0)
        },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        singleLine = true
    )
}

@Composable
private fun SummaryRow(label: String, value: String, highlight: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextSecondary)
        Text(
            value,
            fontWeight = FontWeight.Bold,
            color = if (highlight) GreenDark else TextPrimary
        )
    }
}
