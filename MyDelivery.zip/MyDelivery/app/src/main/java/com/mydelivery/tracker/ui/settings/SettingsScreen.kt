package com.mydelivery.tracker.ui.settings

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mydelivery.tracker.data.AppSettings
import com.mydelivery.tracker.ui.theme.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: SettingsViewModel) {
    val settings by viewModel.settings.collectAsState()
    val message by viewModel.message.collectAsState()
    val context = LocalContext.current

    var rateHour by remember(settings.rateHour) { mutableStateOf(settings.rateHour.toString()) }
    var rateOrder by remember(settings.rateOrder) { mutableStateOf(settings.rateOrder.toString()) }
    var rateHeavy by remember(settings.rateHeavy) { mutableStateOf(settings.rateHeavy.toString()) }
    var rateLate by remember(settings.rateLate) { mutableStateOf(settings.rateLate.toString()) }
    var currency by remember(settings.currency) { mutableStateOf(settings.currency) }

    var pendingExportJson by remember { mutableStateOf<String?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        val json = pendingExportJson
        if (uri != null && json != null) {
            context.contentResolver.openOutputStream(uri)?.use { out ->
                OutputStreamWriter(out).use { it.write(json) }
            }
        }
        pendingExportJson = null
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            context.contentResolver.openInputStream(uri)?.use { input ->
                val text = BufferedReader(InputStreamReader(input)).readText()
                viewModel.importJson(text)
            }
        }
    }

    LaunchedEffect(message) {
        // сообщение показывается через Snackbar ниже
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Настройки", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = White)
            )
        },
        containerColor = White
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { Spacer(Modifier.height(4.dp)) }

            item {
                AppCard {
                    Text("Ставки Самоката", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    RateField("Оплата за час", rateHour) { rateHour = it }
                    RateField("Оплата за заказ (SLA30)", rateOrder) { rateOrder = it }
                    RateField("Оплата за тяжёлый заказ", rateHeavy) { rateHeavy = it }
                    RateField("Оплата за позднюю выдачу", rateLate) { rateLate = it }
                }
            }

            item {
                AppCard {
                    Text("Валюта", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = currency,
                        onValueChange = { currency = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }

            item {
                Button(
                    onClick = {
                        viewModel.save(
                            AppSettings(
                                rateHour = rateHour.toDoubleOrNull() ?: settings.rateHour,
                                rateOrder = rateOrder.toDoubleOrNull() ?: settings.rateOrder,
                                rateHeavy = rateHeavy.toDoubleOrNull() ?: settings.rateHeavy,
                                rateLate = rateLate.toDoubleOrNull() ?: settings.rateLate,
                                currency = currency
                            )
                        )
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green)
                ) {
                    Text("Сохранить настройки", fontWeight = FontWeight.Bold)
                }
            }

            item {
                Text(
                    "Изменение ставок не повлияет на уже сохранённые смены — только на новые.",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }

            item {
                OutlinedButton(
                    onClick = {
                        viewModel.exportJson { json ->
                            pendingExportJson = json
                            exportLauncher.launch("moya-dostavka-backup.json")
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Text("Экспорт данных (JSON)")
                }
            }
            item {
                OutlinedButton(
                    onClick = { importLauncher.launch(arrayOf("application/json")) },
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Text("Импорт данных (JSON)")
                }
            }

            if (message != null) {
                item {
                    AppCard(background = SamokatTint) {
                        Text(message ?: "")
                    }
                }
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun RateField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        singleLine = true
    )
}
