package com.mydelivery.tracker.ui.calendar

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mydelivery.tracker.data.Shift
import com.mydelivery.tracker.model.Formulas
import com.mydelivery.tracker.ui.theme.*
import com.mydelivery.tracker.util.DateUtils
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarScreen(viewModel: CalendarViewModel, currency: String, onEditDay: (LocalDate) -> Unit) {
    val month by viewModel.month.collectAsState()
    val shiftsByDate by viewModel.shiftsByDate.collectAsState()
    var selected by remember { mutableStateOf<LocalDate?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Календарь", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = White)
            )
        },
        containerColor = White
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.shiftMonth(false) }) {
                    Icon(Icons.Default.ChevronLeft, contentDescription = "Назад")
                }
                Text(DateUtils.monthLabel(month), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                IconButton(onClick = { viewModel.shiftMonth(true) }) {
                    Icon(Icons.Default.ChevronRight, contentDescription = "Вперёд")
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth()) {
                DateUtils.weekdayShort.forEach {
                    Text(
                        it,
                        modifier = Modifier.weight(1f),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
            }
            Spacer(Modifier.height(4.dp))

            val firstDay = month
            val leadingEmpty = firstDay.dayOfWeek.value - 1 // Monday=1
            val daysInMonth = firstDay.lengthOfMonth()
            val cells = (0 until leadingEmpty).map { null } + (1..daysInMonth).map { firstDay.withDayOfMonth(it) }

            LazyVerticalGrid(
                columns = GridCells.Fixed(7),
                modifier = Modifier.weight(1f)
            ) {
                items(cells) { date ->
                    if (date == null) {
                        Box(modifier = Modifier.padding(4.dp).height(56.dp))
                    } else {
                        val shift = shiftsByDate[date]
                        DayCell(date, shift, currency) { selected = date }
                    }
                }
            }
        }
    }

    val selDate = selected
    if (selDate != null) {
        DayDetailDialog(
            date = selDate,
            shift = shiftsByDate[selDate],
            currency = currency,
            onDismiss = { selected = null },
            onEdit = { onEditDay(selDate); selected = null }
        )
    }
}

@Composable
private fun DayCell(date: LocalDate, shift: Shift?, currency: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .padding(4.dp)
            .height(56.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (shift != null) CardGray else White)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(date.dayOfMonth.toString(), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            if (shift != null) {
                Text(
                    formatMoney(Formulas.totalIncome(shift), currency).replace(" $currency", ""),
                    style = MaterialTheme.typography.labelSmall,
                    color = GreenDark,
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
private fun DayDetailDialog(
    date: LocalDate,
    shift: Shift?,
    currency: String,
    onDismiss: () -> Unit,
    onEdit: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = onEdit) { Text("Редактировать") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Закрыть") }
        },
        title = { Text("${date.dayOfMonth} ${DateUtils.monthGenitive[date.monthValue - 1]} ${date.year}") },
        text = {
            if (shift == null) {
                Text("Нет данных за этот день.")
            } else {
                Column {
                    DetailLine("Доход Самокат", formatMoney(Formulas.samokatIncome(shift), currency))
                    DetailLine("Доход Яндекс", formatMoney(Formulas.yandexIncome(shift), currency))
                    DetailLine("Чаевые", formatMoney(shift.samokatTips + shift.yandexTips, currency))
                    DetailLine("Расходы", formatMoney(shift.expenses, currency))
                    DetailLine("Чистый доход", formatMoney(Formulas.netIncome(shift), currency))
                    DetailLine("Часы Самокат", formatHours(Formulas.samokatHours(shift)))
                    DetailLine("Часы Яндекс", formatHours(Formulas.yandexHours(shift)))
                    DetailLine("Количество заказов", shift.samokatOrders.toString())
                }
            }
        }
    )
}

@Composable
private fun DetailLine(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
        Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
    }
}
