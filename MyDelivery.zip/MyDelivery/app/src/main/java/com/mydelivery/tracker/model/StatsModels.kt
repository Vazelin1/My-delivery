package com.mydelivery.tracker.model

enum class Period { DAY, WEEK, MONTH, YEAR }

data class PeriodStats(
    val label: String,
    val samokatIncome: Double,
    val samokatHours: Double,
    val samokatOrders: Int,
    val yandexIncome: Double,
    val yandexHours: Double,
    val netIncome: Double,
    val totalIncome: Double,
    val totalHours: Double
) {
    val samokatPerHour: Double get() = if (samokatHours > 0) samokatIncome / samokatHours else 0.0
    val yandexPerHour: Double get() = if (yandexHours > 0) yandexIncome / yandexHours else 0.0
    val totalPerHour: Double get() = if (totalHours > 0) totalIncome / totalHours else 0.0
}
