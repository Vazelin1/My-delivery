package com.mydelivery.tracker.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/**
 * Одна смена курьера за конкретный день.
 * Ставки (rateHour..rateLate) сохраняются "снимком" на момент сохранения смены,
 * поэтому изменение ставок в Настройках не влияет на уже сохранённые смены.
 */
@Entity(tableName = "shifts")
@Serializable
data class Shift(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,

    val dateEpochDay: Long,

    // Самокат
    val samokatStart: String = "",
    val samokatEnd: String = "",
    val samokatOrders: Int = 0,
    val samokatHeavyOrders: Int = 0,
    val samokatLateOrders: Int = 0,
    val samokatTips: Double = 0.0,
    val badWeather: Boolean = false,

    // Яндекс
    val yandexStart: String = "",
    val yandexEnd: String = "",
    val yandexIncome: Double = 0.0,
    val yandexTips: Double = 0.0,

    // Расходы
    val expenses: Double = 0.0,

    // Снимок ставок на момент сохранения
    val rateHour: Double = 200.0,
    val rateOrder: Double = 60.0,
    val rateHeavy: Double = 20.0,
    val rateLate: Double = 30.0,
    val currency: String = "₽"
)
