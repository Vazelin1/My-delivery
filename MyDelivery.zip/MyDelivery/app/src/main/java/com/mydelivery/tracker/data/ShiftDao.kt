package com.mydelivery.tracker.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ShiftDao {

    @Query("SELECT * FROM shifts ORDER BY dateEpochDay DESC")
    fun observeAll(): Flow<List<Shift>>

    @Query("SELECT * FROM shifts")
    suspend fun getAllOnce(): List<Shift>

    @Query("SELECT * FROM shifts WHERE dateEpochDay = :day LIMIT 1")
    suspend fun getByDate(day: Long): Shift?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(shift: Shift): Long

    @Delete
    suspend fun delete(shift: Shift)

    @Query("DELETE FROM shifts")
    suspend fun deleteAll()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(shifts: List<Shift>)
}
