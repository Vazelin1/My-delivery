package com.mydelivery.tracker.ui.calendar

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mydelivery.tracker.data.Shift
import com.mydelivery.tracker.data.ShiftRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import java.time.LocalDate

class CalendarViewModel(private val repository: ShiftRepository) : ViewModel() {

    private val _month = MutableStateFlow(LocalDate.now().withDayOfMonth(1))
    val month: StateFlow<LocalDate> = _month

    private val _shiftsByDate = MutableStateFlow<Map<LocalDate, Shift>>(emptyMap())
    val shiftsByDate: StateFlow<Map<LocalDate, Shift>> = _shiftsByDate

    init {
        repository.observeAll().onEach { list ->
            _shiftsByDate.value = list.associateBy { LocalDate.ofEpochDay(it.dateEpochDay) }
        }.launchIn(viewModelScope)
    }

    fun shiftMonth(forward: Boolean) {
        _month.value = if (forward) _month.value.plusMonths(1) else _month.value.minusMonths(1)
    }
}
