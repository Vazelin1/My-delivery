package com.mydelivery.tracker.ui.nav

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mydelivery.tracker.data.AppSettings
import com.mydelivery.tracker.ui.analytics.AnalyticsScreen
import com.mydelivery.tracker.ui.analytics.AnalyticsViewModel
import com.mydelivery.tracker.ui.calendar.CalendarScreen
import com.mydelivery.tracker.ui.calendar.CalendarViewModel
import com.mydelivery.tracker.ui.home.HomeScreen
import com.mydelivery.tracker.ui.home.HomeViewModel
import com.mydelivery.tracker.ui.settings.SettingsScreen
import com.mydelivery.tracker.ui.settings.SettingsViewModel
import com.mydelivery.tracker.ui.shift.ShiftScreen
import com.mydelivery.tracker.ui.shift.ShiftViewModel
import com.mydelivery.tracker.ui.statistics.StatisticsScreen
import com.mydelivery.tracker.ui.statistics.StatisticsViewModel
import com.mydelivery.tracker.ui.theme.TextSecondary
import com.mydelivery.tracker.ui.theme.White
import java.time.LocalDate

private sealed class Dest(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    data object Home : Dest("home", "Итоги", Icons.Filled.Home)
    data object Statistics : Dest("statistics", "Статистика", Icons.Filled.BarChart)
    data object Analytics : Dest("analytics", "Аналитика", Icons.Filled.Insights)
    data object Calendar : Dest("calendar", "Календарь", Icons.Filled.CalendarMonth)
    data object Settings : Dest("settings", "Профиль", Icons.Filled.Settings)
}

@Composable
fun AppNavGraph(factory: AppViewModelFactory, settings: AppSettings) {
    val navController: NavHostController = rememberNavController()
    val leftItems = listOf(Dest.Home, Dest.Statistics)
    val rightItems = listOf(Dest.Analytics, Dest.Calendar, Dest.Settings)

    Scaffold(
        containerColor = White,
        bottomBar = {
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = backStackEntry?.destination
            val onShift = currentDestination?.hierarchy?.any { it.route?.startsWith("shift") == true } == true

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(White)
                    .padding(horizontal = 6.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                leftItems.forEach { dest ->
                    val selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true
                    BottomNavPillItem(dest.icon, dest.label, selected) {
                        navController.navigate(dest.route) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                }
                // Отдельная кнопка "Смена" — всегда открывает создание новой смены на сегодня
                BottomNavPillItem(Icons.Filled.Add, "Смена", onShift) {
                    navController.navigate("shift/${LocalDate.now().toEpochDay()}")
                }
                rightItems.forEach { dest ->
                    val selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true
                    BottomNavPillItem(dest.icon, dest.label, selected) {
                        navController.navigate(dest.route) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Dest.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Dest.Home.route) {
                val vm: HomeViewModel = viewModel(factory = factory)
                HomeScreen(
                    viewModel = vm,
                    currency = settings.currency,
                    onDayClick = { date ->
                        navController.navigate("shift/${date.toEpochDay()}")
                    }
                )
            }
            composable(
                route = "shift/{epochDay}",
                arguments = listOf(navArgument("epochDay") { type = NavType.LongType })
            ) { backStackEntry ->
                val epochDay = backStackEntry.arguments?.getLong("epochDay") ?: LocalDate.now().toEpochDay()
                val vm: ShiftViewModel = viewModel(factory = factory)
                ShiftScreen(
                    viewModel = vm,
                    date = LocalDate.ofEpochDay(epochDay),
                    settings = settings,
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Dest.Statistics.route) {
                val vm: StatisticsViewModel = viewModel(factory = factory)
                StatisticsScreen(viewModel = vm, currency = settings.currency)
            }
            composable(Dest.Analytics.route) {
                val vm: AnalyticsViewModel = viewModel(factory = factory)
                AnalyticsScreen(viewModel = vm, currency = settings.currency)
            }
            composable(Dest.Calendar.route) {
                val vm: CalendarViewModel = viewModel(factory = factory)
                CalendarScreen(
                    viewModel = vm,
                    currency = settings.currency,
                    onEditDay = { date -> navController.navigate("shift/${date.toEpochDay()}") }
                )
            }
            composable(Dest.Settings.route) {
                val vm: SettingsViewModel = viewModel(factory = factory)
                SettingsScreen(viewModel = vm)
            }
        }
    }
}

@Composable
private fun BottomNavPillItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val bg = if (selected) androidx.compose.ui.graphics.Color.Black else androidx.compose.ui.graphics.Color.Transparent
    val fg = if (selected) White else TextSecondary
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(24.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = fg, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(2.dp))
        Text(label, color = fg, fontSize = 10.sp, fontWeight = FontWeight.Medium)
    }
}
