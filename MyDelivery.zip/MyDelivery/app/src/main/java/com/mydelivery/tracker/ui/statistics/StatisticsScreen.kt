package com.mydelivery.tracker.ui.statistics

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mydelivery.tracker.model.Period
import com.mydelivery.tracker.model.PeriodStats
import com.mydelivery.tracker.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatisticsScreen(viewModel: StatisticsViewModel, currency: String) {
    val period by viewModel.period.collectAsState()
    val label by viewModel.periodLabel.collectAsState()
    val stats by viewModel.stats.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Статистика", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = White)
            )
        },
        containerColor = White
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { Spacer(Modifier.height(4.dp)) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Period.entries.forEach { p ->
                        FilterChip(
                            selected = period == p,
                            onClick = { viewModel.setPeriod(p) },
                            label = { Text(periodTitle(p)) }
                        )
                    }
                }
            }
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.shiftAnchor(false) }) {
                        Icon(Icons.Default.ChevronLeft, contentDescription = "Назад")
                    }
                    Text(label, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleLarge)
                    IconButton(onClick = { viewModel.shiftAnchor(true) }) {
                        Icon(Icons.Default.ChevronRight, contentDescription = "Вперёд")
                    }
                }
            }
            item {
                AppCard(background = SamokatTint) {
                    Text("Самокат", fontWeight = FontWeight.Bold, color = SamokatAccent)
                    Spacer(Modifier.height(8.dp))
                    StatLine("Доход", formatMoney(stats.samokatIncome, currency))
                    StatLine("Часы", formatHours(stats.samokatHours))
                    StatLine("Заказы", stats.samokatOrders.toString())
                    StatLine("Доход в час", formatMoney(stats.samokatPerHour, currency))
                }
            }
            item {
                AppCard(background = YandexTint) {
                    Text("Яндекс", fontWeight = FontWeight.Bold, color = YandexAccent)
                    Spacer(Modifier.height(8.dp))
                    StatLine("Доход", formatMoney(stats.yandexIncome, currency))
                    StatLine("Часы", formatHours(stats.yandexHours))
                    StatLine("Доход в час", formatMoney(stats.yandexPerHour, currency))
                }
            }
            item {
                AppCard {
                    Text("Общая статистика", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    StatLine("Чистый доход", formatMoney(stats.netIncome, currency), valueColor = GreenDark)
                    StatLine("Общий доход", formatMoney(stats.totalIncome, currency))
                    StatLine("Доход в час", formatMoney(stats.totalPerHour, currency))
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

private fun periodTitle(p: Period) = when (p) {
    Period.DAY -> "День"
    Period.WEEK -> "Неделя"
    Period.MONTH -> "Месяц"
    Period.YEAR -> "Год"
}

@Composable
private fun StatLine(label: String, value: String, valueColor: androidx.compose.ui.graphics.Color = TextPrimary) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextSecondary)
        Text(value, fontWeight = FontWeight.Bold, color = valueColor)
    }
}
