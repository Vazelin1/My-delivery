package com.mydelivery.tracker.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/** Базовая карточка со скруглением 18dp и светло-серым фоном. */
@Composable
fun AppCard(
    modifier: Modifier = Modifier,
    background: androidx.compose.ui.graphics.Color = CardGray,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(background)
            .padding(16.dp),
        content = content
    )
}

fun formatMoney(value: Double, currency: String = "₽"): String {
    val rounded = value.roundToInt()
    val s = "%,d".format(rounded).replace(',', ' ')
    return "$s $currency"
}

fun formatHours(hours: Double): String {
    val h = hours.toInt()
    val m = ((hours - h) * 60).roundToInt()
    return if (m == 0) "${h} ч" else "${h} ч ${m} мин"
}

@Composable
fun BigNumber(text: String, color: androidx.compose.ui.graphics.Color = TextPrimary) {
    Text(text = text, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = color)
}
