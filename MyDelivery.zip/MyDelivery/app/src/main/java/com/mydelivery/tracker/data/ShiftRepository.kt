package com.mydelivery.tracker.data

import kotlinx.coroutines.flow.Flow

class ShiftRepository(private val dao: ShiftDao) {
    fun observeAll(): Flow<List<Shift>> = dao.observeAll()
    suspend fun getAllOnce(): List<Shift> = dao.getAllOnce()
    suspend fun getByDate(day: Long): Shift? = dao.getByDate(day)
    suspend fun save(shift: Shift): Long = dao.upsert(shift)
    suspend fun delete(shift: Shift) = dao.delete(shift)
    suspend fun replaceAll(shifts: List<Shift>) {
        dao.deleteAll()
        dao.insertAll(shifts)
    }
}
