package com.mydelivery.tracker.data

import android.content.Context
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable

val Context.dataStore by preferencesDataStore("settings")

@Serializable
data class AppSettings(
    val rateHour: Double = 200.0,
    val rateOrder: Double = 60.0,
    val rateHeavy: Double = 20.0,
    val rateLate: Double = 30.0,
    val currency: String = "₽"
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val RATE_HOUR = doublePreferencesKey("rate_hour")
        val RATE_ORDER = doublePreferencesKey("rate_order")
        val RATE_HEAVY = doublePreferencesKey("rate_heavy")
        val RATE_LATE = doublePreferencesKey("rate_late")
        val CURRENCY = stringPreferencesKey("currency")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { p ->
        AppSettings(
            rateHour = p[Keys.RATE_HOUR] ?: 200.0,
            rateOrder = p[Keys.RATE_ORDER] ?: 60.0,
            rateHeavy = p[Keys.RATE_HEAVY] ?: 20.0,
            rateLate = p[Keys.RATE_LATE] ?: 30.0,
            currency = p[Keys.CURRENCY] ?: "₽"
        )
    }

    suspend fun update(settings: AppSettings) {
        context.dataStore.edit { p ->
            p[Keys.RATE_HOUR] = settings.rateHour
            p[Keys.RATE_ORDER] = settings.rateOrder
            p[Keys.RATE_HEAVY] = settings.rateHeavy
            p[Keys.RATE_LATE] = settings.rateLate
            p[Keys.CURRENCY] = settings.currency
        }
    }
}
