package com.mydelivery.tracker.util

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters

object DateUtils {

    val monthGenitive = listOf(
        "января", "февраля", "марта", "апреля", "мая", "июня",
        "июля", "августа", "сентября", "октября", "ноября", "декабря"
    )
    val monthNominative = listOf(
        "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
        "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"
    )
    val weekdayShort = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
    val weekdayFull = listOf(
        "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"
    )

    fun mondayOf(date: LocalDate): LocalDate = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    fun sundayOf(date: LocalDate): LocalDate = date.with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY))

    fun weekRangeLabel(monday: LocalDate): String {
        val sunday = monday.plusDays(6)
        return if (monday.month == sunday.month) {
            "${monday.dayOfMonth}–${sunday.dayOfMonth} ${monthGenitive[monday.monthValue - 1]}"
        } else if (monday.year == sunday.year) {
            "${monday.dayOfMonth} ${monthGenitive[monday.monthValue - 1]} – ${sunday.dayOfMonth} ${monthGenitive[sunday.monthValue - 1]}"
        } else {
            "${monday.dayOfMonth} ${monthGenitive[monday.monthValue - 1]} ${monday.year} – ${sunday.dayOfMonth} ${monthGenitive[sunday.monthValue - 1]} ${sunday.year}"
        }
    }

    fun isWeekend(date: LocalDate): Boolean =
        date.dayOfWeek == DayOfWeek.SATURDAY || date.dayOfWeek == DayOfWeek.SUNDAY

    fun monthLabel(date: LocalDate): String = "${monthNominative[date.monthValue - 1]} ${date.year}"

    fun shortDate(date: LocalDate): String = "${date.dayOfMonth} ${monthGenitive[date.monthValue - 1]}"

    /** Формат "06.07" - двузначные день и месяц. */
    fun shortDateNumeric(date: LocalDate): String = "%02d.%02d".format(date.dayOfMonth, date.monthValue)
}
