package com.mydelivery.tracker.ui.statistics

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mydelivery.tracker.data.Shift
import com.mydelivery.tracker.data.ShiftRepository
import com.mydelivery.tracker.model.Formulas
import com.mydelivery.tracker.model.Period
import com.mydelivery.tracker.model.PeriodStats
import com.mydelivery.tracker.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import java.time.LocalDate

class StatisticsViewModel(private val repository: ShiftRepository) : ViewModel() {

    private val _period = MutableStateFlow(Period.WEEK)
    val period: StateFlow<Period> = _period

    private val _anchor = MutableStateFlow(LocalDate.now())
    val anchor: StateFlow<LocalDate> = _anchor

    private val _allShifts = MutableStateFlow<List<Shift>>(emptyList())

    private val _stats = MutableStateFlow(emptyStats(""))
    val stats: StateFlow<PeriodStats> = _stats

    private val _periodLabel = MutableStateFlow("")
    val periodLabel: StateFlow<String> = _periodLabel

    init {
        repository.observeAll().onEach { _allShifts.value = it; recompute() }.launchIn(viewModelScope)
    }

    fun setPeriod(p: Period) { _period.value = p; recompute() }

    fun shiftAnchor(forward: Boolean) {
        _anchor.value = when (_period.value) {
            Period.DAY -> if (forward) _anchor.value.plusDays(1) else _anchor.value.minusDays(1)
            Period.WEEK -> if (forward) _anchor.value.plusWeeks(1) else _anchor.value.minusWeeks(1)
            Period.MONTH -> if (forward) _anchor.value.plusMonths(1) else _anchor.value.minusMonths(1)
            Period.YEAR -> if (forward) _anchor.value.plusYears(1) else _anchor.value.minusYears(1)
        }
        recompute()
    }

    private fun recompute() {
        val anchor = _anchor.value
        val (start, end, label) = when (_period.value) {
            Period.DAY -> Triple(anchor, anchor, DateUtils.shortDate(anchor))
            Period.WEEK -> {
                val monday = DateUtils.mondayOf(anchor)
                Triple(monday, monday.plusDays(6), DateUtils.weekRangeLabel(monday))
            }
            Period.MONTH -> {
                val first = anchor.withDayOfMonth(1)
                val last = first.plusMonths(1).minusDays(1)
                Triple(first, last, DateUtils.monthLabel(anchor))
            }
            Period.YEAR -> {
                val first = LocalDate.of(anchor.year, 1, 1)
                val last = LocalDate.of(anchor.year, 12, 31)
                Triple(first, last, anchor.year.toString())
            }
        }
        _periodLabel.value = label

        val filtered = _allShifts.value.filter {
            val d = LocalDate.ofEpochDay(it.dateEpochDay)
            !d.isBefore(start) && !d.isAfter(end)
        }

        _stats.value = PeriodStats(
            label = label,
            samokatIncome = filtered.sumOf { Formulas.samokatIncome(it) },
            samokatHours = filtered.sumOf { Formulas.samokatHours(it) },
            samokatOrders = filtered.sumOf { it.samokatOrders },
            yandexIncome = filtered.sumOf { Formulas.yandexIncome(it) },
            yandexHours = filtered.sumOf { Formulas.yandexHours(it) },
            netIncome = filtered.sumOf { Formulas.netIncome(it) },
            totalIncome = filtered.sumOf { Formulas.totalIncome(it) },
            totalHours = filtered.sumOf { Formulas.totalHours(it) }
        )
    }

    private fun emptyStats(label: String) = PeriodStats(label, 0.0, 0.0, 0, 0.0, 0.0, 0.0, 0.0, 0.0)
}
