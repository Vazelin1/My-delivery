package com.mydelivery.tracker.ui.shift

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mydelivery.tracker.data.AppSettings
import com.mydelivery.tracker.data.Shift
import com.mydelivery.tracker.data.ShiftRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate

class ShiftViewModel(private val repository: ShiftRepository) : ViewModel() {

    private val _shift = MutableStateFlow<Shift?>(null)
    val shift: StateFlow<Shift?> = _shift

    private val _isNew = MutableStateFlow(true)
    val isNew: StateFlow<Boolean> = _isNew

    fun load(date: LocalDate, settings: AppSettings) {
        viewModelScope.launch {
            val existing = repository.getByDate(date.toEpochDay())
            if (existing != null) {
                _shift.value = existing
                _isNew.value = false
            } else {
                _shift.value = Shift(
                    dateEpochDay = date.toEpochDay(),
                    rateHour = settings.rateHour,
                    rateOrder = settings.rateOrder,
                    rateHeavy = settings.rateHeavy,
                    rateLate = settings.rateLate,
                    currency = settings.currency
                )
                _isNew.value = true
            }
        }
    }

    fun update(transform: (Shift) -> Shift) {
        _shift.value = _shift.value?.let(transform)
    }

    fun save(onDone: () -> Unit) {
        val s = _shift.value ?: return
        viewModelScope.launch {
            repository.save(s)
            onDone()
        }
    }

    fun delete(onDone: () -> Unit) {
        val s = _shift.value ?: return
        viewModelScope.launch {
            repository.delete(s)
            onDone()
        }
    }
}
