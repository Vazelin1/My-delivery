package com.mydelivery.tracker.ui.analytics

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mydelivery.tracker.data.Shift
import com.mydelivery.tracker.data.ShiftRepository
import com.mydelivery.tracker.model.*
import com.mydelivery.tracker.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import java.time.LocalDate

class AnalyticsViewModel(private val repository: ShiftRepository) : ViewModel() {

    private val _allShifts = MutableStateFlow<List<Shift>>(emptyList())

    private val _weekAnchor = MutableStateFlow(LocalDate.now())
    val weekAnchor: StateFlow<LocalDate> = _weekAnchor
    private val _weekLabel = MutableStateFlow("")
    val weekLabel: StateFlow<String> = _weekLabel

    private val _weekdayBreakdown = MutableStateFlow<List<WeekdayBreakdownRow>>(emptyList())
    val weekdayBreakdown: StateFlow<List<WeekdayBreakdownRow>> = _weekdayBreakdown

    private val _samokatBestHours = MutableStateFlow(BestHoursBlock(emptyList(), emptyList()))
    val samokatBestHours: StateFlow<BestHoursBlock> = _samokatBestHours

    private val _yandexBestHours = MutableStateFlow(BestHoursBlock(emptyList(), emptyList()))
    val yandexBestHours: StateFlow<BestHoursBlock> = _yandexBestHours

    private val _records = MutableStateFlow(Records(null, 0.0, null, 0.0, null, 0))
    val records: StateFlow<Records> = _records

    init {
        repository.observeAll().onEach {
            _allShifts.value = it
            recomputeWeek()
            recomputeBestHours()
            recomputeRecords()
        }.launchIn(viewModelScope)
    }

    fun shiftWeek(forward: Boolean) {
        _weekAnchor.value = if (forward) _weekAnchor.value.plusWeeks(1) else _weekAnchor.value.minusWeeks(1)
        recomputeWeek()
    }

    private fun recomputeWeek() {
        val monday = DateUtils.mondayOf(_weekAnchor.value)
        _weekLabel.value = DateUtils.weekRangeLabel(monday)
        val byDate = _allShifts.value.associateBy { LocalDate.ofEpochDay(it.dateEpochDay) }
        _weekdayBreakdown.value = (0..6).map { offset ->
            val date = monday.plusDays(offset.toLong())
            val shift = byDate[date]
            val hours = shift?.let { Formulas.totalHours(it) } ?: 0.0
            val income = shift?.let { Formulas.totalIncome(it) } ?: 0.0
            WeekdayBreakdownRow(
                weekdayName = DateUtils.weekdayFull[offset],
                date = date,
                hours = hours,
                income = income,
                incomePerHour = if (hours > 0) income / hours else 0.0
            )
        }
    }

    /** Лучшие часы за предыдущий полный календарный месяц. */
    private fun recomputeBestHours() {
        val today = LocalDate.now()
        val prevMonthFirst = today.minusMonths(1).withDayOfMonth(1)
        val prevMonthLast = prevMonthFirst.plusMonths(1).minusDays(1)

        val monthShifts = _allShifts.value.filter {
            val d = LocalDate.ofEpochDay(it.dateEpochDay)
            !d.isBefore(prevMonthFirst) && !d.isAfter(prevMonthLast)
        }

        _samokatBestHours.value = computeBestHours(monthShifts, isYandex = false)
        _yandexBestHours.value = computeBestHours(monthShifts, isYandex = true)
    }

    private fun computeBestHours(shifts: List<Shift>, isYandex: Boolean): BestHoursBlock {
        // bucket[weekday=0/weekend=1][hour 0..23] -> список ставок в час
        val buckets = Array(2) { Array(24) { mutableListOf<Double>() } }

        shifts.forEach { shift ->
            val date = LocalDate.ofEpochDay(shift.dateEpochDay)
            val typeIdx = if (DateUtils.isWeekend(date)) 1 else 0
            val start = if (isYandex) shift.yandexStart else shift.samokatStart
            val end = if (isYandex) shift.yandexEnd else shift.samokatEnd
            val hours = Formulas.hoursBetween(start, end)
            if (hours <= 0) return@forEach
            val income = if (isYandex) Formulas.yandexIncome(shift) else Formulas.samokatIncome(shift)
            val rate = income / hours
            val startHour = start.split(":").getOrNull(0)?.toIntOrNull() ?: return@forEach
            var h = startHour
            var remaining = Math.ceil(hours).toInt().coerceAtLeast(1)
            repeat(remaining) {
                buckets[typeIdx][h % 24].add(rate)
                h++
            }
        }

        fun windowsFor(typeIdx: Int): List<HourWindow> {
            val hourAvg = DoubleArray(24) { h -> buckets[typeIdx][h].let { if (it.isEmpty()) 0.0 else it.average() } }
            val windows = (0..21).map { start ->
                val avg = (hourAvg[start] + hourAvg[start + 1] + hourAvg[start + 2]) / 3.0
                HourWindow(start, start + 3, avg)
            }
            return windows.filter { it.ratePerHour > 0 }.sortedByDescending { it.ratePerHour }.take(3)
        }

        return BestHoursBlock(
            weekdayWindows = windowsFor(0),
            weekendWindows = windowsFor(1)
        )
    }

    private fun recomputeRecords() {
        val shifts = _allShifts.value
        if (shifts.isEmpty()) {
            _records.value = Records(null, 0.0, null, 0.0, null, 0)
            return
        }
        val bestShift = shifts.maxByOrNull { Formulas.totalIncome(it) }
        val bestPerHour = shifts.maxByOrNull { Formulas.incomePerHour(it) }
        val maxOrders = shifts.maxByOrNull { it.samokatOrders }

        _records.value = Records(
            bestShiftDate = bestShift?.let { LocalDate.ofEpochDay(it.dateEpochDay) },
            bestShiftIncome = bestShift?.let { Formulas.totalIncome(it) } ?: 0.0,
            bestPerHourDate = bestPerHour?.let { LocalDate.ofEpochDay(it.dateEpochDay) },
            bestPerHour = bestPerHour?.let { Formulas.incomePerHour(it) } ?: 0.0,
            maxOrdersDate = maxOrders?.let { LocalDate.ofEpochDay(it.dateEpochDay) },
            maxOrders = maxOrders?.samokatOrders ?: 0
        )
    }
}
