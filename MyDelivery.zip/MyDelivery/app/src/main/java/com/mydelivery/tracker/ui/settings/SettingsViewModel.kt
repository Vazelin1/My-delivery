package com.mydelivery.tracker.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mydelivery.tracker.data.AppSettings
import com.mydelivery.tracker.data.SettingsRepository
import com.mydelivery.tracker.data.ShiftRepository
import com.mydelivery.tracker.util.BackupData
import com.mydelivery.tracker.util.JsonBackup
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val shiftRepository: ShiftRepository
) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepository.settingsFlow.stateIn(
        viewModelScope, SharingStarted.Eagerly, AppSettings()
    )

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    fun save(settings: AppSettings) {
        viewModelScope.launch { settingsRepository.update(settings) }
    }

    fun exportJson(onReady: (String) -> Unit) {
        viewModelScope.launch {
            val shifts = shiftRepository.getAllOnce()
            val data = BackupData(settings.value, shifts)
            onReady(JsonBackup.toJson(data))
        }
    }

    fun importJson(text: String) {
        viewModelScope.launch {
            try {
                val data = JsonBackup.fromJson(text)
                shiftRepository.replaceAll(data.shifts)
                settingsRepository.update(data.settings)
                _message.value = "Данные успешно восстановлены"
            } catch (e: Exception) {
                _message.value = "Ошибка импорта: файл повреждён"
            }
        }
    }

    fun clearMessage() { _message.value = null }
}
