package com.mydelivery.tracker.ui.analytics

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mydelivery.tracker.model.HourWindow
import com.mydelivery.tracker.model.WeekdayBreakdownRow
import com.mydelivery.tracker.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyticsScreen(viewModel: AnalyticsViewModel, currency: String) {
    val weekLabel by viewModel.weekLabel.collectAsState()
    val breakdown by viewModel.weekdayBreakdown.collectAsState()
    val samokatBest by viewModel.samokatBestHours.collectAsState()
    val yandexBest by viewModel.yandexBestHours.collectAsState()
    val records by viewModel.records.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Аналитика", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = White)
            )
        },
        containerColor = White
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { Spacer(Modifier.height(4.dp)) }

            item { Text("Доход по дням недели", style = MaterialTheme.typography.titleLarge) }
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.shiftWeek(false) }) {
                        Icon(Icons.Default.ChevronLeft, contentDescription = "Назад")
                    }
                    Text(weekLabel, fontWeight = FontWeight.SemiBold)
                    IconButton(onClick = { viewModel.shiftWeek(true) }) {
                        Icon(Icons.Default.ChevronRight, contentDescription = "Вперёд")
                    }
                }
            }
            item {
                AppCard {
                    breakdown.forEachIndexed { i, row ->
                        WeekdayRow(row, currency)
                        if (i != breakdown.lastIndex) Divider(color = DividerColor, thickness = 0.5.dp)
                    }
                }
            }

            item { Text("Лучшие часы", style = MaterialTheme.typography.titleLarge) }
            item {
                AppCard(background = SamokatTint) {
                    Text("Самокат", fontWeight = FontWeight.Bold, color = SamokatAccent)
                    Spacer(Modifier.height(8.dp))
                    BestHoursSection("Будни", samokatBest.weekdayWindows, currency)
                    Spacer(Modifier.height(8.dp))
                    BestHoursSection("Выходные", samokatBest.weekendWindows, currency)
                }
            }
            item {
                AppCard(background = YandexTint) {
                    Text("Яндекс", fontWeight = FontWeight.Bold, color = YandexAccent)
                    Spacer(Modifier.height(8.dp))
                    BestHoursSection("Будни", yandexBest.weekdayWindows, currency)
                    Spacer(Modifier.height(8.dp))
                    BestHoursSection("Выходные", yandexBest.weekendWindows, currency)
                }
            }

            item { Text("Рекорды", style = MaterialTheme.typography.titleLarge) }
            item {
                AppCard {
                    RecordLine(
                        "Лучшая смена по доходу",
                        formatMoney(records.bestShiftIncome, currency),
                        records.bestShiftDate
                    )
                    Divider(color = DividerColor, thickness = 0.5.dp)
                    RecordLine(
                        "Лучший доход в час",
                        formatMoney(records.bestPerHour, currency) + "/ч",
                        records.bestPerHourDate
                    )
                    Divider(color = DividerColor, thickness = 0.5.dp)
                    RecordLine(
                        "Максимум заказов (Самокат)",
                        "${records.maxOrders} зак.",
                        records.maxOrdersDate
                    )
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun WeekdayRow(row: WeekdayBreakdownRow, currency: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(row.weekdayName, fontWeight = FontWeight.SemiBold)
            Text(
                "${"%02d".format(row.date.dayOfMonth)}.${"%02d".format(row.date.monthValue)}",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(formatMoney(row.income, currency), fontWeight = FontWeight.Bold, color = GreenDark)
            Text(
                "${formatHours(row.hours)} · ${formatMoney(row.incomePerHour, currency)}/ч",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
        }
    }
}

@Composable
private fun BestHoursSection(title: String, windows: List<HourWindow>, currency: String) {
    Text(title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
    if (windows.isEmpty()) {
        Text("Недостаточно данных", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    } else {
        windows.forEach { w ->
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(w.label, color = TextSecondary)
                Text("${formatMoney(w.ratePerHour, currency)}/ч", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun RecordLine(label: String, value: String, date: java.time.LocalDate?) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(label, color = TextSecondary)
            if (date != null) {
                Text(
                    "${"%02d".format(date.dayOfMonth)}.${"%02d".format(date.monthValue)}.${date.year}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }
        }
        Text(value, fontWeight = FontWeight.Bold)
    }
}
