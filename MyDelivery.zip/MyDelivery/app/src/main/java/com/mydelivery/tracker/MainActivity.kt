package com.mydelivery.tracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.mydelivery.tracker.data.AppSettings
import com.mydelivery.tracker.ui.nav.AppNavGraph
import com.mydelivery.tracker.ui.nav.AppViewModelFactory
import com.mydelivery.tracker.ui.theme.MyDeliveryTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as MyDeliveryApp
        val factory = AppViewModelFactory(app.shiftRepository, app.settingsRepository)

        setContent {
            val settings by app.settingsRepository.settingsFlow.collectAsState(initial = AppSettings())
            MyDeliveryTheme {
                AppNavGraph(factory = factory, settings = settings)
            }
        }
    }
}
