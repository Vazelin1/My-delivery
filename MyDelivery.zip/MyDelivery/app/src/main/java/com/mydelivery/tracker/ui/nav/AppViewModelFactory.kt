package com.mydelivery.tracker.ui.nav

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.mydelivery.tracker.data.SettingsRepository
import com.mydelivery.tracker.data.ShiftRepository
import com.mydelivery.tracker.ui.analytics.AnalyticsViewModel
import com.mydelivery.tracker.ui.calendar.CalendarViewModel
import com.mydelivery.tracker.ui.home.HomeViewModel
import com.mydelivery.tracker.ui.settings.SettingsViewModel
import com.mydelivery.tracker.ui.shift.ShiftViewModel
import com.mydelivery.tracker.ui.statistics.StatisticsViewModel

class AppViewModelFactory(
    private val shiftRepository: ShiftRepository,
    private val settingsRepository: SettingsRepository
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when (modelClass) {
            HomeViewModel::class.java -> HomeViewModel(shiftRepository) as T
            ShiftViewModel::class.java -> ShiftViewModel(shiftRepository) as T
            StatisticsViewModel::class.java -> StatisticsViewModel(shiftRepository) as T
            AnalyticsViewModel::class.java -> AnalyticsViewModel(shiftRepository) as T
            CalendarViewModel::class.java -> CalendarViewModel(shiftRepository) as T
            SettingsViewModel::class.java -> SettingsViewModel(settingsRepository, shiftRepository) as T
            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
