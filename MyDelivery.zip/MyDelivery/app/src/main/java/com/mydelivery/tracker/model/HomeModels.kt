package com.mydelivery.tracker.model

import java.time.LocalDate

data class MonthSummary(
    val monthDate: LocalDate, // first day of month
    val label: String,
    val income: Double,
    val workedDays: Int,
    val workedHours: Double
)

data class DayRow(
    val date: LocalDate,
    val hasShift: Boolean,
    val income: Double,
    val samokatHours: Double,
    val samokatOrders: Int,
    val yandexHours: Double,
    val incomePerHour: Double
)

data class WeekGroup(
    val monday: LocalDate,
    val label: String,
    val days: List<DayRow>
)
