package com.mydelivery.tracker.model

import com.mydelivery.tracker.data.Shift

/**
 * Все формулы расчёта дохода курьера.
 */
object Formulas {

    /** Часы между начало/конец в формате "HH:mm". Если конец раньше начала - считаем, что смена перешла через полночь. */
    fun hoursBetween(start: String, end: String): Double {
        if (start.isBlank() || end.isBlank()) return 0.0
        val s = parseMinutes(start) ?: return 0.0
        var e = parseMinutes(end) ?: return 0.0
        if (e <= s) e += 24 * 60
        return (e - s) / 60.0
    }

    private fun parseMinutes(hhmm: String): Int? {
        val parts = hhmm.split(":")
        if (parts.size != 2) return null
        val h = parts[0].toIntOrNull() ?: return null
        val m = parts[1].toIntOrNull() ?: return null
        return h * 60 + m
    }

    fun samokatHours(s: Shift) = hoursBetween(s.samokatStart, s.samokatEnd)
    fun yandexHours(s: Shift) = hoursBetween(s.yandexStart, s.yandexEnd)

    /** Доход Самокат = часы*ставка_час + заказы*ставка_заказ + тяжёлые*ставка_тяжёлый
     *  + чаевые + (заказы*10 если плохая погода) + поздние*ставка_поздняя */
    fun samokatIncome(s: Shift): Double {
        val weatherBonus = if (s.badWeather) s.samokatOrders * 10.0 else 0.0
        return samokatHours(s) * s.rateHour +
            s.samokatOrders * s.rateOrder +
            s.samokatHeavyOrders * s.rateHeavy +
            s.samokatTips +
            weatherBonus +
            s.samokatLateOrders * s.rateLate
    }

    /** Доход Яндекс = доход + чаевые */
    fun yandexIncome(s: Shift): Double = s.yandexIncome + s.yandexTips

    fun totalIncome(s: Shift): Double = samokatIncome(s) + yandexIncome(s)

    fun netIncome(s: Shift): Double = totalIncome(s) - s.expenses

    fun totalHours(s: Shift): Double = samokatHours(s) + yandexHours(s)

    fun incomePerHour(s: Shift): Double {
        val h = totalHours(s)
        return if (h > 0) totalIncome(s) / h else 0.0
    }
}
