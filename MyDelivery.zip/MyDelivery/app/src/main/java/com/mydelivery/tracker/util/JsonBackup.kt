package com.mydelivery.tracker.util

import com.mydelivery.tracker.data.AppSettings
import com.mydelivery.tracker.data.Shift
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
data class BackupData(
    val settings: AppSettings,
    val shifts: List<Shift>
)

object JsonBackup {
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }

    fun toJson(data: BackupData): String = json.encodeToString(data)

    fun fromJson(text: String): BackupData = json.decodeFromString(text)
}
