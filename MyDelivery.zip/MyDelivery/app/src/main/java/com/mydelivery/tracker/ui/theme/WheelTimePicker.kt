package com.mydelivery.tracker.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Колесо-барабан для выбора одного числового значения (часы или минуты).
 * Пользователь листает пальцем, значение по центру - выбранное.
 */
@Composable
private fun WheelColumn(
    values: List<Int>,
    selected: Int,
    onSelected: (Int) -> Unit,
    format: (Int) -> String = { it.toString().padStart(2, '0') }
) {
    val itemHeight = 44.dp
    val visibleCount = 5 // нечётное, чтобы был явный центр
    val padCount = visibleCount / 2
    val startIndex = values.indexOf(selected).coerceAtLeast(0)
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = startIndex)

    LaunchedEffect(listState.isScrollInProgress) {
        if (!listState.isScrollInProgress) {
            val centerIndex = listState.firstVisibleItemIndex
            val value = values.getOrNull(centerIndex.coerceIn(0, values.lastIndex))
            if (value != null && value != selected) onSelected(value)
        }
    }

    Box(
        modifier = Modifier
            .height(itemHeight * visibleCount)
            .width(70.dp),
        contentAlignment = Alignment.Center
    ) {
        // Полоска-подсветка центрального значения
        Box(
            modifier = Modifier
                .height(itemHeight)
                .fillMaxWidth()
                .background(CardGray, RoundedCornerShape(12.dp))
        )
        LazyColumn(
            state = listState,
            flingBehavior = rememberSnapFlingBehavior(listState),
            contentPadding = PaddingValues(vertical = itemHeight * padCount),
            modifier = Modifier.fillMaxSize()
        ) {
            itemsIndexed(values) { index, value ->
                val isCenter = index == listState.firstVisibleItemIndex
                Box(
                    modifier = Modifier.height(itemHeight).fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = format(value),
                        fontSize = if (isCenter) 22.sp else 17.sp,
                        fontWeight = if (isCenter) FontWeight.Bold else FontWeight.Normal,
                        color = if (isCenter) TextPrimary else TextSecondary
                    )
                }
            }
        }
    }
}

/** Диалог выбора времени "часы : минуты" колёсиками с шагом минут 5. */
@Composable
fun WheelTimePickerDialog(
    initialTime: String, // "HH:mm" либо ""
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    val parts = initialTime.split(":")
    val initHour = parts.getOrNull(0)?.toIntOrNull() ?: 9
    val initMinute = (parts.getOrNull(1)?.toIntOrNull() ?: 0).let { m -> (m / 5) * 5 }

    var hour by remember { mutableStateOf(initHour.coerceIn(0, 23)) }
    var minute by remember { mutableStateOf(initMinute.coerceIn(0, 55)) }

    val hours = (0..23).toList()
    val minutes = (0..55 step 5).toList()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Выберите время") },
        text = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                WheelColumn(values = hours, selected = hour, onSelected = { hour = it })
                Spacer(Modifier.width(4.dp))
                Text(":", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(4.dp))
                WheelColumn(values = minutes, selected = minute, onSelected = { minute = it })
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onConfirm("%02d:%02d".format(hour, minute))
            }) { Text("Готово") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}

/** Поле-кнопка, при нажатии открывающая колёсики выбора времени. */
@Composable
fun TimePickerField(label: String, value: String, onChange: (String) -> Unit) {
    var showDialog by remember { mutableStateOf(false) }

    OutlinedButton(
        onClick = { showDialog = true },
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = TextSecondary)
            Text(
                if (value.isBlank()) "Выбрать" else value,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }
    }

    if (showDialog) {
        WheelTimePickerDialog(
            initialTime = value,
            onDismiss = { showDialog = false },
            onConfirm = { newValue ->
                onChange(newValue)
                showDialog = false
            }
        )
    }
}
