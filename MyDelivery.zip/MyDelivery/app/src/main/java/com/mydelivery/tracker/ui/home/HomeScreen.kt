package com.mydelivery.tracker.ui.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mydelivery.tracker.model.DayRow
import com.mydelivery.tracker.model.MonthSummary
import com.mydelivery.tracker.model.WeekGroup
import com.mydelivery.tracker.ui.theme.*
import com.mydelivery.tracker.util.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    currency: String,
    onDayClick: (java.time.LocalDate) -> Unit
) {
    val months by viewModel.months.collectAsState()
    val weeks by viewModel.weeks.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Моя доставка", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = White)
            )
        },
        containerColor = White
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Spacer(Modifier.height(4.dp)) }
            item {
                Text("Доход по месяцам", style = MaterialTheme.typography.titleLarge)
            }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(months) { m -> MonthCard(m, currency) }
                }
            }
            item {
                Spacer(Modifier.height(8.dp))
                Text("История смен", style = MaterialTheme.typography.titleLarge)
            }
            items(weeks) { week ->
                WeekBlock(week = week, currency = currency, onDayClick = onDayClick)
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun MonthCard(month: MonthSummary, currency: String) {
    AppCard(modifier = Modifier.width(150.dp)) {
        Text(month.label, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        Spacer(Modifier.height(6.dp))
        Text(
            formatMoney(month.income, currency),
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(8.dp))
        Text("${month.workedDays} раб. дней", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Text(formatHours(month.workedHours), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    }
}

@Composable
private fun WeekBlock(week: WeekGroup, currency: String, onDayClick: (java.time.LocalDate) -> Unit) {
    AppCard {
        Text(week.label, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        week.days.forEach { day ->
            DayRowItem(day, currency) { onDayClick(day.date) }
            Divider(color = DividerColor, thickness = 0.5.dp)
        }
    }
}

@Composable
private fun DayRowItem(day: DayRow, currency: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.width(64.dp)) {
            Text(
                DateUtils.weekdayShort[day.date.dayOfWeek.value - 1],
                fontWeight = FontWeight.SemiBold
            )
            Text(
                "${day.date.dayOfMonth}.${day.date.monthValue}",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            if (day.hasShift) {
                Text(
                    formatMoney(day.income, currency),
                    color = GreenDark,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Самокат: ${formatHours(day.samokatHours)} · ${day.samokatOrders} зак.",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
                Text(
                    "Яндекс: ${formatHours(day.yandexHours)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            } else {
                Text("Нет данных", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
        }
        if (day.hasShift) {
            Text(
                "${formatMoney(day.incomePerHour, currency)}/ч",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
        }
    }
}
