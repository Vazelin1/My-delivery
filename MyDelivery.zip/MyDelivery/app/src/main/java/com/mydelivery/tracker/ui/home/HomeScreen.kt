package com.mydelivery.tracker.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mydelivery.tracker.model.DayRow
import com.mydelivery.tracker.model.MonthSummary
import com.mydelivery.tracker.model.WeekGroup
import com.mydelivery.tracker.ui.theme.*
import com.mydelivery.tracker.util.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    currency: String,
    onDayClick: (java.time.LocalDate) -> Unit
) {
    val months by viewModel.months.collectAsState()
    val weeks by viewModel.weeks.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Моя доставка", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = White)
            )
        },
        containerColor = White
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Spacer(Modifier.height(4.dp)) }
            item {
                Text("ИТОГИ ПО МЕСЯЦАМ", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontWeight = FontWeight.Bold)
            }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(months) { m -> MonthCard(m, currency) }
                }
            }
            item {
                Spacer(Modifier.height(8.dp))
                Text("ИСТОРИЯ СМЕН", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontWeight = FontWeight.Bold)
            }
            items(weeks) { week ->
                WeekBlock(
                    week = week,
                    currency = currency,
                    onDayClick = onDayClick,
                    onDeleteDay = { date -> viewModel.deleteShift(date) }
                )
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun MonthCard(month: MonthSummary, currency: String) {
    AppCard(modifier = Modifier.width(160.dp), background = MonthCardTint) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                month.label.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.height(8.dp))
        Text("ЗАРАБОТАНО", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Text(
            formatMoney(month.income, currency),
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = GreenDark
        )
        Spacer(Modifier.height(8.dp))
        Divider(color = DividerColor, thickness = 0.5.dp)
        Spacer(Modifier.height(8.dp))
        Text("${month.workedDays} раб. дней", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Text(formatHours(month.workedHours), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    }
}

@Composable
private fun WeekBlock(
    week: WeekGroup,
    currency: String,
    onDayClick: (java.time.LocalDate) -> Unit,
    onDeleteDay: (java.time.LocalDate) -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                week.label.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                fontWeight = FontWeight.Bold
            )
            Box(
                modifier = Modifier
                    .background(CardGray, androidx.compose.foundation.shape.RoundedCornerShape(20.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(formatMoney(week.weekTotal, currency), fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(6.dp))
        AppCard {
            week.days.forEachIndexed { idx, day ->
                DayRowItem(day, currency, onClick = { onDayClick(day.date) }, onDelete = { onDeleteDay(day.date) })
                if (idx != week.days.lastIndex) Divider(color = DividerColor, thickness = 0.5.dp)
            }
        }
    }
}

@Composable
private fun DayRowItem(day: DayRow, currency: String, onClick: () -> Unit, onDelete: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.width(64.dp)) {
                Text(
                    DateUtils.weekdayShort[day.date.dayOfWeek.value - 1],
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    DateUtils.shortDateNumeric(day.date),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                if (day.hasShift) {
                    Text(
                        "Самокат: ${formatHours(day.samokatHours)} · ${day.samokatOrders} зак.",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                    Text(
                        "Яндекс: ${formatHours(day.yandexHours)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                } else {
                    Text("Нет данных", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
            if (day.hasShift) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        formatMoney(day.income, currency),
                        color = GreenDark,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "${formatMoney(day.incomePerHour, currency)}/ч",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.Delete, contentDescription = "Удалить", tint = TextSecondary)
                }
            }
        }
        if (day.hasShift && (day.badWeather && day.weatherBonusAmount > 0 || day.lateOrders > 0)) {
            Row(
                modifier = Modifier.padding(top = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (day.badWeather && day.weatherBonusAmount > 0) {
                    BonusPill("Плохая погода ×${day.samokatOrders} ${formatMoney(day.weatherBonusAmount, currency)}")
                }
                if (day.lateOrders > 0) {
                    BonusPill("Поздние выдачи ×${day.lateOrders} ${formatMoney(day.lateBonusAmount, currency)}")
                }
            }
        }
    }
}

@Composable
private fun BonusPill(text: String) {
    Box(
        modifier = Modifier
            .background(CardGray, androidx.compose.foundation.shape.RoundedCornerShape(20.dp))
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(text, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    }
}
