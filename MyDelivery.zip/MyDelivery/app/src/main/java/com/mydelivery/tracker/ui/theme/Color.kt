package com.mydelivery.tracker.ui.theme

import androidx.compose.ui.graphics.Color

val White = Color(0xFFFFFFFF)
val CardGray = Color(0xFFF5F5F7)
val CardGrayDark = Color(0xFFECECEF)
val Green = Color(0xFF2ECC71)
val GreenDark = Color(0xFF1FA45A)
val TextPrimary = Color(0xFF1C1C1E)
val TextSecondary = Color(0xFF8A8A8E)

val SamokatTint = Color(0xFFFBE7E7)
val SamokatAccent = Color(0xFFE05B5B)

val YandexTint = Color(0xFFFFF6D9)
val YandexAccent = Color(0xFFD8A400)

val DividerColor = Color(0xFFEDEDED)
